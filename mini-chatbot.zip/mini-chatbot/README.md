# FastAPI AI Chatbot

A simple AI chatbot built using:

- Python
- FastAPI
- OpenAI Chat Completions API
- uv

## Project Structure

```text
fastapi-chatbot/
├── app/
│   ├── main.py
│   ├── config.py
│   ├── schemas.py
│   └── services/
│       └── chat.py
├── .env
├── .env.example
├── .gitignore
└── pyproject.toml