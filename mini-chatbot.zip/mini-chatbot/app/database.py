from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.config import DATABASE_URL

# represents the connection configuration to PostgreSQL
engine = create_engine(DATABASE_URL)

# creates database sessions.
session = sessionmaker(
    autocommit = False,
    bind=engine
)

def get_db():
    # get_db is a generator function that provides a database session to the caller. It ensures that the session is properly closed after use.

    # session() creates a new database session using the configured engine.
    db = session()

    try:
        # yield allows the function to return a value and then resume execution later. In this case, it provides a database session to the caller.
        yield db
    finally:
        db.close()