"""Application configuration.

Loads environment variables from the local .env file and exposes the values used
by the chat service.
"""

import os

# os module provides a way of using operating system dependent functionality like reading environment variables.

from dotenv import load_dotenv

# dotenv is a Python library that reads key-value pairs from a .env file and can set them as environment variables.
load_dotenv()

# load_dotenv() reads the .env file and loads the environment variables into the process's environment.

# The following variables are loaded from the environment and used by the chat service.
LLM_API_KEY = os.getenv("LLM_API_KEY")
LLM_MODEl = os.getenv("LLM_MODEl")
DATABASE_URL = os.getenv("DATABSE_URL")

if not LLM_API_KEY:
    raise ValueError("LLM API KEY is not configured.")