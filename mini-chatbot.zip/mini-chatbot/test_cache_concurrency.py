import concurrent.futures
import requests


URL = "http://127.0.0.1:8000/users/1"
NUMBER_OF_REQUESTS = 20


def send_request():
    response = requests.get(URL)
    return response.status_code


with concurrent.futures.ThreadPoolExecutor(
    max_workers=NUMBER_OF_REQUESTS
) as executor:

    results = list(
        executor.map(
            lambda _: send_request(),
            range(NUMBER_OF_REQUESTS),
        )
    )


print("Status codes:", results)
print("Total requests:", len(results))
print("Successful requests:", results.count(200))