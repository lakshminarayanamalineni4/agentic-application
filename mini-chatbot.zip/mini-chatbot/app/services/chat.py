"""Chat service for the mini chatbot.

This service keeps a small conversation history and calls the configured LLM
provider using the OpenAI-compatible client.
"""

from app.config import LLM_API_KEY, LLM_MODEl
from openai import OpenAI


class ChatService:
    def __init__(self):
        # Use the configured API key and OpenRouter-compatible base URL.
        self.client = OpenAI(
            api_key=LLM_API_KEY,
            base_url="https://openrouter.ai/api/v1",
        )
        self.model = LLM_MODEl

        # Keep the system message and conversation history for context.
        self.messages = [
            {
                "role": "system",
                "content": (
                    "You are a helpful AI assistant. "
                    "Answer clearly and concisely."
                ),
            }
        ]

    def chat(self, user_message: str) -> str:
        # Add the latest user message before sending the request.
        self.messages.append(
            {
                "role": "user",
                "content": user_message,
            }
        )

        response = self.client.chat.completions.create(
            model=self.model,
            messages=self.messages,
        )

        assistant_message = response.choices[0].message.content

        # Store the assistant reply so future responses remain contextual.
        self.messages.append(
            {
                "role": "assistant",
                "content": assistant_message,
            }
        )

        return assistant_message