from fastapi import FastAPI, HTTPException, Depends
from app.services.chat import ChatService
from app.schemas import ChatRequest, ChatResponse, UserCreate, UserUpdate, UserResponse, CacheConfigRequest
from sqlalchemy.orm import Session
import time
from app.models import Base, User
from app.database import engine, get_db
from app.cache import UserCache

app = FastAPI()

# Create the database tables based on the defined models.
# create_all()

# Good for:

# learning
# prototypes
# very small coding exercises

# But it doesn't give you proper schema migration management.

# Alembic

# Used for:

# Production
#      ↓
# Database migrations
#      ↓
# Versioned schema changes

# For example:

# Migration 001
# Create users

# Migration 002
# Add phone_number

# Migration 003
# Add status

# Migration 004
# Add chat_messages
Base.metadata.create_all(bind=engine)

chat_service = ChatService()

user_cache = UserCache(
    max_size=3,
    ttl_seconds=20,
)

@app.get("/")
def health_check():
    return {"msg": "App is running successfully.."}


@app.post('/users', response_model=UserResponse, status_code=201)
def create_user(user:UserCreate, db: Session = Depends(get_db)):
    existing_user = (
        db.query(User)
        .filter(User.email == user.email)
        .first() 
    )
    
    if existing_user:
        raise HTTPException(
            status_code=409,
            detail= f"User with email {user.email} already exists."
        )

    new_user = User(
        name = user.name,
        email = user.email
    )

    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    return new_user

@app.get("/users", response_model=list[UserResponse])
def get_all_users(db: Session = Depends(get_db)):
    users = db.query(User).order_by(User.id).all()

    return users

@app.get("/users/{user_id}", response_model=UserResponse)
def get_user(
    user_id: int,
    db: Session = Depends(get_db),
):
    user = user_cache.get(
        user_id,
        lambda user_id: (
            db.query(User)
            .filter(User.id == user_id)
            .first()
        ),
    )

    if not user:
        raise HTTPException(
            status_code=404,
            detail="User not found",
        )

    return user

# @app.put("/users/{user_id}", response_model=UserResponse)
# def update_user(
#     user_id: int,
#     user: UserUpdate,
#     db: Session = Depends(get_db),
# ):
#     existing_user = (
#         db.query(User)
#         .filter(User.id == user_id)
#         .first()
#     )

#     if not existing_user:
#         raise HTTPException(
#             status_code=404,
#             detail="User not found",
#         )

#     if user.name:
#         existing_user.name = user.name

#     if user.email:
#         existing_email = (
#             db.query(User)
#             .filter(
#                 User.email == user.email,
#                 User.id != user_id,
#             )
#             .first()
#         )

#         if existing_email:
#             raise HTTPException(
#                 status_code=409,
#                 detail="Email Already Exists",
#             )

#         existing_user.email = user.email

#     db.commit()
#     db.refresh(existing_user)

#     # Invalidate stale cached value.
#     user_cache.delete(user_id)

#     return existing_user


# @app.delete("/users/{user_id}")
# def delete_user(
#     user_id: int,
#     db: Session = Depends(get_db),
# ):
#     user = (
#         db.query(User)
#         .filter(User.id == user_id)
#         .first()
#     )

#     if not user:
#         raise HTTPException(
#             status_code=404,
#             detail="User not found",
#         )

#     db.delete(user)
#     db.commit()

#     user_cache.delete(user_id)

#     return {
#         "message": "User deleted successfully"
#     }

@app.get("/cache/stats")
def cache_stats():
    return user_cache.stats()

# @app.put("/cache/config")
# def configure_cache(config: CacheConfigRequest):
    user_cache.configure(
        max_size=config.max_size,
        ttl_seconds=config.ttl_seconds,
    )

    return user_cache.stats()