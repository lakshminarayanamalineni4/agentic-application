from collections import OrderedDict
from dataclasses import dataclass
from threading import Event, RLock
from time import monotonic
from typing import Any, Callable


# Represents one item stored in the cache.
# It stores:
#   value       -> the actual cached user
#   expires_at  -> the exact time when the cached value expires
@dataclass
class CacheEntry:
    value: Any
    expires_at: float


class UserCache:

    def __init__(
        self,
        max_size: int = 3,
        ttl_seconds: int = 20,
    ):
        # Maximum number of users that can be stored in memory.
        # This is configurable and can be changed using configure().
        self.max_size = max_size

        # Time-to-live for each cached user.
        # After this duration, the cached entry is considered expired.
        self.ttl_seconds = ttl_seconds

        # Statistics used to observe cache behavior.
        self._hits = 0
        self._misses = 0
        self._loader_calls = 0

        # OrderedDict is used to implement LRU.
        #
        # The order represents:
        #     first item  -> Least Recently Used
        #     last item   -> Most Recently Used
        #
        # Example:
        #     [1, 2, 3]
        #
        # User 1 = LRU
        # User 3 = MRU
        self._cache: OrderedDict[int, CacheEntry] = OrderedDict()

        # RLock makes access to the cache thread-safe.
        #
        # Multiple threads can call get() at the same time,
        # but only one thread can modify the protected state
        # at a time.
        self._lock = RLock()

        # Tracks database lookups currently in progress.
        #
        # user_id -> Event
        #
        # This is used for request coalescing / single-flight.
        #
        # If 20 threads request the same missing user:
        #
        #     Thread 1 -> performs DB lookup
        #     Thread 2 -> waits
        #     Thread 3 -> waits
        #     ...
        #     Thread 20 -> waits
        #
        # Therefore only ONE database lookup is performed.
        self._inflight: dict[int, Event] = {}

    def get(
        self,
        user_id: int,
        loader: Callable[[int], Any],
    ) -> Any:

        # -----------------------------------------
        # 1. Check the cache
        # -----------------------------------------

        # The lock protects the cache and other shared state
        # from concurrent access by multiple threads.
        with self._lock:

            # Try to find the requested user in the cache.
            entry = self._cache.get(user_id)

            if entry is not None:

                # Check whether the cached entry is still valid.
                #
                # monotonic() is used instead of time.time()
                # because it is designed for measuring elapsed time
                # and is not affected by system clock changes.
                if entry.expires_at > monotonic():

                    # The user was found and is still valid.
                    self._hits += 1

                    # Move the user to the end because it was
                    # recently accessed.
                    #
                    # The end represents the Most Recently Used item.
                    self._cache.move_to_end(user_id)

                    # Return the cached value without querying DB.
                    return entry.value

                # The entry exists but its TTL has expired.
                # Remove the stale entry from the cache.
                del self._cache[user_id]

            # The requested user was not available in the cache,
            # or the existing entry had expired.
            self._misses += 1

            # -----------------------------------------
            # 2. Check if another thread is already
            #    loading this user
            # -----------------------------------------

            event = self._inflight.get(user_id)

            if event is None:

                # No other thread is loading this user.
                #
                # This thread becomes responsible for performing
                # the database lookup.
                event = Event()

                # Mark this user as currently being loaded.
                self._inflight[user_id] = event

                is_loader = True

            else:

                # Another thread is already loading this user.
                #
                # This thread should NOT perform another DB call.
                is_loader = False

        # -----------------------------------------
        # 3. Wait for another thread's DB call
        # -----------------------------------------

        if not is_loader:

            # Wait until the thread performing the DB lookup
            # finishes and calls event.set().
            event.wait()

            # The database result should now be available in cache.
            with self._lock:

                entry = self._cache.get(user_id)

                if entry is not None:

                    # Make sure the newly cached value has not
                    # already expired.
                    if entry.expires_at > monotonic():

                        # This thread has now accessed the user,
                        # so mark it as most recently used.
                        self._cache.move_to_end(user_id)

                        return entry.value

            # The loader either failed or the user did not exist.
            return None

        # -----------------------------------------
        # 4. This thread performs the DB lookup
        # -----------------------------------------

        try:

            # Track the actual number of database loader calls.
            #
            # This is useful for demonstrating that 20 concurrent
            # requests result in only ONE DB call.
            with self._lock:
                self._loader_calls += 1

            # IMPORTANT:
            # The lock is NOT held while calling the database.
            #
            # This allows other threads to access the cache while
            # this potentially slow database operation is running.
            value = loader(user_id)

            # Only cache the value if the database returned a user.
            if value is not None:

                with self._lock:

                    # Store the user in the cache.
                    self._cache[user_id] = CacheEntry(
                        value=value,

                        # Calculate the exact expiration time.
                        expires_at=monotonic() + self.ttl_seconds,
                    )

                    # The newly inserted user is the most recently used.
                    self._cache.move_to_end(user_id)

                    # If the cache exceeds its maximum capacity,
                    # remove the least recently used entries.
                    #
                    # last=False means remove from the beginning,
                    # which represents the LRU item.
                    while len(self._cache) > self.max_size:
                        self._cache.popitem(last=False)

            return value

        finally:

            # -----------------------------------------
            # 5. Wake up waiting threads
            # -----------------------------------------

            # This executes even if the database loader raises
            # an exception.
            with self._lock:

                # Remove the user from the "currently loading" map.
                self._inflight.pop(user_id, None)

                # Wake up all threads waiting for this user.
                event.set()

    def stats(self) -> dict:

        # Return information about the current cache state.
        # The lock ensures that the statistics represent a
        # consistent view of the cache.
        with self._lock:

            return {
                # Current maximum cache capacity.
                "max_size": self.max_size,

                # Current TTL configuration.
                "ttl_seconds": self.ttl_seconds,

                # Number of users currently stored in memory.
                "current_size": len(self._cache),

                # Number of users currently being loaded from DB.
                "inflight_requests": len(self._inflight),

                # Number of successful cache lookups.
                "cache_hits": self._hits,

                # Number of requests that did not find a valid
                # entry in the cache.
                "cache_misses": self._misses,

                # Actual number of database loader executions.
                #
                # This is particularly useful for demonstrating
                # the single-flight/concurrent request requirement.
                "database_loader_calls": self._loader_calls,

                # Current LRU order.
                #
                # First item  -> Least Recently Used
                # Last item   -> Most Recently Used
                "cache_keys_lru_order": list(self._cache.keys()),
            }

    def configure(
        self,
        max_size: int | None = None,
        ttl_seconds: int | None = None,
    ) -> None:

        # Dynamically update cache configuration.
        #
        # Both parameters are optional, so we can change either
        # one independently.
        with self._lock:

            # -----------------------------------------
            # Update maximum cache size
            # -----------------------------------------

            if max_size is not None:

                if max_size <= 0:
                    raise ValueError(
                        "max_size must be greater than 0"
                    )

                self.max_size = max_size

                # If the new capacity is smaller than the
                # current number of cached users, immediately
                # remove the oldest entries until the cache
                # satisfies the new limit.
                while len(self._cache) > self.max_size:
                    self._cache.popitem(last=False)

            # -----------------------------------------
            # Update TTL
            # -----------------------------------------

            if ttl_seconds is not None:

                if ttl_seconds <= 0:
                    raise ValueError(
                        "ttl_seconds must be greater than 0"
                    )

                self.ttl_seconds = ttl_seconds
