"""Pydantic models used by the FastAPI chat endpoint.

These models validate the request body and define the shape of the API response.
"""
from datetime import datetime
from pydantic import BaseModel, Field, EmailStr, ConfigDict
# BaseModel is the base class for Pydantic models. Which contains validation and serialization logic by default.
# Field is used to provide additional metadata and validation rules for model fields.
# Pydantic's EmailStr uses the email-validator package. uv add email-validator

class UserCreate(BaseModel):
    name: str = Field(
        ...,
        min_length=1,
        max_length=100
    ),
    email: EmailStr

class UserUpdate(BaseModel):
    name: str|None = Field(default=None, min_length=1, max_length=100)
    email: EmailStr| None = None

class UserResponse(BaseModel):
    id: int
    name: str
    email: EmailStr
    created_at: datetime
    updated_at: datetime

    # allows Pydantic to build the response schema from a SQLAlchemy object.
    model_config = ConfigDict(
        from_attributes=True
    )

class ChatRequest(BaseModel):
    # The user message must be present and non-empty.
    # ... means the field is required.
    message: str = Field(..., min_length=1)


class ChatResponse(BaseModel):
    # The API response contains a single answer string.
    answer: str


class CacheConfigRequest(BaseModel):
    max_size: int | None = Field(default=None, gt=0)
    ttl_seconds: int | None = Field(default=None, gt=0)