from datetime import datetime

from sqlalchemy import DateTime, String

# declarative_base is a factory function that constructs a base class for declarative class definitions. It is used to define the base class for all SQLAlchemy ORM models.
# Mapped is a generic type that represents a mapped column in an ORM model. It is used to define the type of a column in the database.
# mapped_column is a function that defines a column in an ORM model. It is used to specify the properties of a column, such as its type, constraints, and default values.
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    """Base class for all SQLAlchemy ORM models."""


class User(Base):
    """Application user record."""

    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)

    name: Mapped[str] = mapped_column(String(100), nullable=False)

    email: Mapped[str] = mapped_column(
        String(250),
        unique=True,
        nullable=False,
        index=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        nullable=False,
    )

    updated_at: Mapped[datetime] = mapped_column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow,
        nullable=False,
    )